import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AgmCoreModule } from '@agm/core';


import { AppComponent } from './app.component';
import { MainComponent } from './main/main.component';
import { InfoComponent } from './info/info.component';
import { UserComponent } from './user/user.component';
import { RouterModule, Routes} from '@angular/router';
import {CommonModule} from '@angular/common';

const appRoutes : Routes = [

  {
    path: 'info',
    component: InfoComponent
  }

];


@NgModule({
  declarations: [
    AppComponent,
    MainComponent,
    InfoComponent,
    UserComponent
  ],
  imports: [
    CommonModule,
    RouterModule,
    BrowserModule,
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyDiI8z9dj-5U5YiiwFMyTQr7mzCPnpGcJs'
    })
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
