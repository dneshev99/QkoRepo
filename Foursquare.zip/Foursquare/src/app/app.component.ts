import {Component, ViewChild} from '@angular/core';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = '4/8Square';
  lat = 51.678418;
  lng = 7.809007;
}



